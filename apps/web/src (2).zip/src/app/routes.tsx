import { createBrowserRouter } from "react-router";
import { PremiumLayout } from "./components/PremiumLayout";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { DashboardPage } from "./pages/DashboardPage";
import { ProjectOverviewPage } from "./pages/ProjectOverviewPage";
import { ProjectTasksPage } from "./pages/ProjectTasksPage";
import { ProjectsListPage } from "./pages/ProjectsListPage";
import { TeamPage } from "./pages/TeamPage";
import { TimePage } from "./pages/TimePage";
import { VerificationsPage } from "./pages/VerificationsPage";
import { GitHubSettingsPage } from "./pages/GitHubSettingsPage";
import { ProjectSettingsPage } from "./pages/ProjectSettingsPage";
import { AISettingsPage } from "./pages/AISettingsPage";
import { TeamMemberProfilePage } from "./pages/TeamMemberProfilePage";
import { PlaceholderPage } from "./pages/PlaceholderPage";
import Login from "./pages/Login";
import ProfileSetup from "./pages/ProfileSetup";
import GithubMemberSetup from "./pages/GithubMemberSetup";

export const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/setup-profile",
    element: <ProtectedRoute><ProfileSetup /></ProtectedRoute>,
  },
  {
    path: "/setup-github",
    element: <ProtectedRoute><GithubMemberSetup /></ProtectedRoute>,
  },
  {
    path: "/",
    element: <ProtectedRoute><PremiumLayout /></ProtectedRoute>,
    children: [
      { 
        index: true, 
        element: <DashboardPage /> 
      },
      {
        path: "verifications",
        element: <VerificationsPage />
      },
      {
        path: "team",
        element: <ProtectedRoute requireAdmin><TeamPage /></ProtectedRoute>
      },
      {
        path: "team/:id",
        element: <TeamMemberProfilePage />
      },
      {
        path: "time",
        element: <TimePage />
      },
      {
        path: "chat",
        element: <PlaceholderPage title="Chat" description="Team messaging and collaboration." />
      },
      {
        path: "projects",
        element: <ProjectsListPage />
      },
      {
        path: "project/:id/overview",
        element: <ProjectOverviewPage />
      },
      {
        path: "project/:id/tasks",
        element: <ProjectTasksPage />
      },
      {
        path: "project/:id/verifications",
        element: <PlaceholderPage title="Project Verifications" description="Task verifications for this project." />
      },
      {
        path: "project/:id/documents",
        element: <PlaceholderPage title="Project Documents" description="Manage project documentation and files." />
      },
      {
        path: "project/:id/settings",
        element: <ProtectedRoute requireAdmin><ProjectSettingsPage /></ProtectedRoute>
      },
      {
        path: "github-settings",
        element: <ProtectedRoute requireAdmin><GitHubSettingsPage /></ProtectedRoute>
      },
      {
        path: "ai-settings",
        element: <ProtectedRoute requireAdmin><AISettingsPage /></ProtectedRoute>
      },
    ],
  },
]);